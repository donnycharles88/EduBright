package com.capstone.education.edubright.data.response

data class PredictRequest(
    val text: String
)
