package com.capstone.education.edubright.data.pref

data class UserModel(
    val name: String,
    val token: String,
    val isLogin: Boolean
)