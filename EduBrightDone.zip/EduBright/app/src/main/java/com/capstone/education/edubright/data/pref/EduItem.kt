package com.capstone.education.edubright.data.pref

data class EduItem(
    val title: String,
    val author: String,
    val description: String,
    val photoResId: Int
)
